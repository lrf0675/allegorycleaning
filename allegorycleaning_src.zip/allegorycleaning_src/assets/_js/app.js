// @codekit-append "../../bower_components/jquery/dist/jquery.js";
// @codekit-append "../../bower_components/parallax.js/parallax.js";
// @codekit-append "../../bower_components/skrollr/dist/skrollr.min.js";
// @codekit-append "../../bower_components/skrollr-menu/dist/skrollr.menu.min.js";

// @codekit-append "../../bower_components/bxslider/jquery.bxSlider.min.js";

// @codekit-append "custom.js";